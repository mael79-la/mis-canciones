# 🎵 Guía PWA — Mi Biblioteca Musical

Sigue estos 4 pasos para convertir tu sitio en una app instalable.

---

## Paso 1 — Subir archivos al repo

Sube **toda esta carpeta** a la raíz de tu repositorio `mis-canciones`.  
La estructura final debe quedar así:

```
mis-canciones/
├── index.html          ← el tuyo (solo agregarle código)
├── manifest.json       ← NUEVO ✅
├── sw.js               ← NUEVO ✅
├── offline.html        ← NUEVO ✅
├── icon-source.svg     ← NUEVO ✅ (referencia visual)
└── icons/
    ├── icon-72.png     ← NUEVO ✅
    ├── icon-96.png
    ├── icon-128.png
    ├── icon-144.png
    ├── icon-152.png
    ├── icon-192.png
    ├── icon-384.png
    └── icon-512.png    ← NUEVO ✅
```

---

## Paso 2 — Agregar al `<head>` de tu `index.html`

Pega estas líneas **dentro de `<head>`**, antes del cierre `</head>`:

```html
<!-- ── PWA ────────────────────────────────────────── -->
<link rel="manifest" href="/mis-canciones/manifest.json" />
<meta name="theme-color" content="#1a1035" />
<meta name="mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
<meta name="apple-mobile-web-app-title" content="MiBiblioteca" />

<!-- Iconos para iOS (no lee el manifest) -->
<link rel="apple-touch-icon" sizes="152x152" href="/mis-canciones/icons/icon-152.png" />
<link rel="apple-touch-icon" sizes="192x192" href="/mis-canciones/icons/icon-192.png" />
<!-- ─────────────────────────────────────────────── -->
```

---

## Paso 3 — Registrar el Service Worker

Pega esto **antes del cierre `</body>`** en tu `index.html`:

```html
<!-- ── Service Worker ─────────────────────────────── -->
<script>
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker
        .register('/mis-canciones/sw.js', { scope: '/mis-canciones/' })
        .then(reg => console.log('[PWA] SW registrado:', reg.scope))
        .catch(err => console.error('[PWA] Error SW:', err));
    });
  }
</script>
<!-- ─────────────────────────────────────────────── -->
```

---

## Paso 4 — (Opcional) Botón "Instalar app"

Si quieres mostrar un botón de instalación en tu UI, agrega esto:

```html
<!-- En el HTML, donde quieras el botón -->
<button id="btn-instalar" style="display:none">📲 Instalar app</button>

<script>
  let deferredPrompt;

  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    document.getElementById('btn-instalar').style.display = 'block';
  });

  document.getElementById('btn-instalar').addEventListener('click', async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    console.log('[PWA] Instalación:', outcome);
    deferredPrompt = null;
    document.getElementById('btn-instalar').style.display = 'none';
  });

  window.addEventListener('appinstalled', () => {
    console.log('[PWA] App instalada ✅');
  });
</script>
```

---

## ✅ Verificar que funciona

1. Sube todo a GitHub y espera ~1 minuto.
2. Abre `https://mael79-la.github.io/mis-canciones/` en Chrome (Android) o Safari (iOS).
3. Chrome Android: toca el menú ⋮ → "Añadir a pantalla de inicio".
4. Safari iOS: toca el ícono compartir → "Añadir a inicio".
5. Para inspeccionar: Chrome DevTools → pestaña **Application** → Manifest / Service Workers.

### Verificación rápida con Lighthouse
En Chrome DevTools → pestaña Lighthouse → marcar "Progressive Web App" → Generate report.
Debería salir verde en todas las categorías PWA.

---

## 🔧 Personalización del `sw.js`

Si tu `index.html` carga archivos CSS o JS locales, agrégalos al array `APP_SHELL` en `sw.js`:

```js
const APP_SHELL = [
  '/mis-canciones/',
  '/mis-canciones/index.html',
  '/mis-canciones/style.css',   // ← agregar si existe
  '/mis-canciones/app.js',      // ← agregar si existe
  ...
];
```

---

## 📌 Colores del tema

Si quieres cambiar el color morado oscuro por el color de tu app, edita:
- `manifest.json` → `theme_color` y `background_color`
- `index.html` → `<meta name="theme-color" ...>`
- `offline.html` → variable `background` en el CSS
